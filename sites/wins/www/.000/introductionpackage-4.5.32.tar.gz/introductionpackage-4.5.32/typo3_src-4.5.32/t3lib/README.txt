TYPO3 Library


The "t3lib/" contains PHP-classes providing core
functionalities of TYPO3 such as manipulation the
database (tce_main.php), providing user authentication
and datatransfer to the TYPO3 backend to name a few.

Please refer to the document "Inside TYPO3" for details on the TYPO3 core.
The document "TYPO3 Core API" will also contain information on these classes.