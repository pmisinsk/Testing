<?php
$MLANG['default']['tabs_images']['tab'] = 'user.gif';
$MLANG['default']['ll_ref']='LLL:EXT:lang/locallang_mod_usertools.xml';

$MCONF['defaultMod']='task';
$MCONF['name']='user';
$MCONF['access']='user,group';
?>